import NovaVet.CitaMedica;
import NovaVet.Mascota;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main2 extends JFrame {
    private ArrayList<Mascota> listaMascotas = new ArrayList<>();
    private JButton agregarMascotaButton;
    private JButton modificarEnfermedadesButton;
    private JButton citaMedicaButton;
    private JButton listarMascotasButton;
    private JButton buscarMascotaButton;

    public Main2() {
        // Configuración básica del JFrame
        setTitle("Gestión de Mascotas");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear paneles
        JPanel mainPanel = new JPanel(new GridLayout(5, 1));

        // Crear botones
        agregarMascotaButton = new JButton("Agregar Mascota");
        modificarEnfermedadesButton = new JButton("Modificar Enfermedades");
        citaMedicaButton = new JButton("Cita Médica");
        listarMascotasButton = new JButton("Lista de Mascotas");
        buscarMascotaButton = new JButton("Buscar Mascota");

        // Agregar acciones a los botones
        agregarMascotaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirPanelAgregarMascota();


            }
        });

        modificarEnfermedadesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirPanelModificarEnfermedades();
            }
        });

        citaMedicaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirPanelCitaMedica();
            }
        });

        listarMascotasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarMascotas();
            }
        });

        buscarMascotaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirPanelBuscarMascota();
            }
        });

        // Agregar botones al panel
        mainPanel.add(agregarMascotaButton);
        mainPanel.add(modificarEnfermedadesButton);
        mainPanel.add(citaMedicaButton);
        mainPanel.add(listarMascotasButton);
        mainPanel.add(buscarMascotaButton);

        // Agregar panel al JFrame
        add(mainPanel);

        // Hacer visible la interfaz
        setVisible(true);
    }

    private void abrirPanelAgregarMascota() {
        JPanel panelAgregarMascota = new JPanel(new GridLayout(10, 2));

        JTextField idField = new JTextField();
        JTextField nombreField = new JTextField();
        JTextField tipoAnimalField = new JTextField();
        JTextField razaField = new JTextField();
        JTextField tamanoField = new JTextField();
        JTextField edadField = new JTextField();
        JTextField pesoField = new JTextField();

        panelAgregarMascota.add(new JLabel("ID de la mascota:"));
        panelAgregarMascota.add(idField);
        panelAgregarMascota.add(new JLabel("Nombre de la mascota:"));
        panelAgregarMascota.add(nombreField);
        panelAgregarMascota.add(new JLabel("Tipo de animal:"));
        panelAgregarMascota.add(tipoAnimalField);
        panelAgregarMascota.add(new JLabel("Raza de la mascota:"));
        panelAgregarMascota.add(razaField);
        panelAgregarMascota.add(new JLabel("Tamaño de la mascota:"));
        panelAgregarMascota.add(tamanoField);
        panelAgregarMascota.add(new JLabel("Edad de la mascota:"));
        panelAgregarMascota.add(edadField);
        panelAgregarMascota.add(new JLabel("Peso de la mascota:"));
        panelAgregarMascota.add(pesoField);

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nuevaID = idField.getText();
                    for (Mascota mascota : listaMascotas) {
                        if (mascota.getID().equals(nuevaID)) {
                            JOptionPane.showMessageDialog(null, "Ya existe una mascota con el mismo ID. Por favor, elija un ID único.");
                            return;
                        }
                    }

                    String nombre = nombreField.getText();
                    String tipoAnimal = tipoAnimalField.getText();
                    String raza = razaField.getText();
                    String tamano = tamanoField.getText();
                    int edad = Integer.parseInt(edadField.getText());
                    double peso = Double.parseDouble(pesoField.getText());

                    Mascota nuevaMascota = new Mascota(
                            nuevaID,
                            nombre,
                            tipoAnimal,
                            raza,
                            tamano,
                            edad,
                            peso,
                            new ArrayList<>(),
                            false,
                            LocalDate.now(),
                            new ArrayList<>(),
                            new ArrayList<>()
                    );

                    listaMascotas.add(nuevaMascota);
                    listaMascotas.add(nuevaMascota);

                    JOptionPane.showMessageDialog(null, "Mascota agregada con éxito.");
                    cerrarPanelActual();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Error en el formato de entrada. Por favor, ingrese datos válidos.");
                }
            }
        });

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarPanelActual();
            }
        });

        panelAgregarMascota.add(confirmarButton);
        panelAgregarMascota.add(volverButton);

        actualizarPanel(panelAgregarMascota);
    }

    private void abrirPanelModificarEnfermedades() {
        JPanel panelModificarEnfermedades = new JPanel(new GridLayout(3, 1));

        JTextField idMascotaField = new JTextField();
        JTextField nuevasEnfermedadesField = new JTextField();

        panelModificarEnfermedades.add(new JLabel("ID de la mascota a modificar:"));
        panelModificarEnfermedades.add(idMascotaField);
        panelModificarEnfermedades.add(new JLabel("Nuevas enfermedades (separadas por coma):"));
        panelModificarEnfermedades.add(nuevasEnfermedadesField);

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idMascota = idMascotaField.getText();

                Mascota mascotaSeleccionada = buscarMascotaPorID(idMascota);

                if (mascotaSeleccionada == null) {
                    JOptionPane.showMessageDialog(null, "Mascota no encontrada con ID: " + idMascota);
                    return;
                }

                String[] nuevasEnfermedadesArray = nuevasEnfermedadesField.getText().split(",");
                mascotaSeleccionada.getEnfermedades().clear();
                for (String enfermedad : nuevasEnfermedadesArray) {
                    mascotaSeleccionada.agregarEnfermedad(enfermedad.trim());
                }

                JOptionPane.showMessageDialog(null, "Enfermedades de la mascota modificadas con éxito.");
                cerrarPanelActual();
            }
        });

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarPanelActual();
            }
        });

        panelModificarEnfermedades.add(confirmarButton);
        panelModificarEnfermedades.add(volverButton);

        actualizarPanel(panelModificarEnfermedades);
    }

    private void abrirPanelCitaMedica() {
        JPanel panelCitaMedica = new JPanel(new GridLayout(4, 1));

        JTextField idMascotaField = new JTextField();
        JTextField fechaField = new JTextField();
        JTextField motivoField = new JTextField();
        JTextField resultadoField = new JTextField();

        panelCitaMedica.add(new JLabel("ID de la mascota para agendar la cita médica:"));
        panelCitaMedica.add(idMascotaField);
        panelCitaMedica.add(new JLabel("Fecha de la cita médica (Formato YYYY-MM-DD):"));
        panelCitaMedica.add(fechaField);
        panelCitaMedica.add(new JLabel("Motivo de la cita médica:"));
        panelCitaMedica.add(motivoField);
        panelCitaMedica.add(new JLabel("Resultado de la cita médica:"));
        panelCitaMedica.add(resultadoField);

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String idMascota = idMascotaField.getText();
                    Mascota mascotaSeleccionada = buscarMascotaPorID(idMascota);

                    if (mascotaSeleccionada == null) {
                        JOptionPane.showMessageDialog(null, "Mascota no encontrada con ID: " + idMascota);
                        return;
                    }

                    LocalDate fechaCita = LocalDate.parse(fechaField.getText());
                    String motivoCita = motivoField.getText();
                    String resultadoCita = resultadoField.getText();

                    CitaMedica nuevaCita = new CitaMedica(fechaCita, motivoCita, resultadoCita);

                    mascotaSeleccionada.agregarCitaMedica(nuevaCita);

                    JOptionPane.showMessageDialog(null, "Cita médica agendada con éxito para la mascota con ID: " + idMascota);
                    cerrarPanelActual();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error en el formato de entrada. Por favor, ingrese datos válidos.");
                }
            }
        });

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarPanelActual();
            }
        });

        panelCitaMedica.add(confirmarButton);
        panelCitaMedica.add(volverButton);

        actualizarPanel(panelCitaMedica);
    }

    private void listarMascotas() {
        if (listaMascotas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay mascotas registradas.");
            return;
        }

        StringBuilder mensaje = new StringBuilder("Lista de todas las mascotas:\n\n");

        for (Mascota mascota : listaMascotas) {
            mensaje.append("ID: ").append(mascota.getID()).append("\n");
            mensaje.append("Nombre: ").append(mascota.getNombre()).append("\n");
            mensaje.append("Tipo de Animal: ").append(mascota.getTipoAnimal()).append("\n");
            mensaje.append("Raza: ").append(mascota.getRaza()).append("\n");
            mensaje.append("Tamaño: ").append(mascota.getTamano()).append("\n");
            mensaje.append("Edad: ").append(mascota.getEdad()).append(" años\n");
            mensaje.append("Peso: ").append(mascota.getPeso()).append(" kg\n");
            mensaje.append("Fecha de Ingreso: ").append(mascota.getFechaIngreso()).append("\n");
            mensaje.append("Enfermedades: ").append(String.join(", ", mascota.getEnfermedades())).append("\n");
            mensaje.append("Esterilizado: ").append(mascota.isEsterilizado() ? "Sí" : "No").append("\n");
            mensaje.append("Adoptada: ").append(mascota.isAdoptada() ? "Sí" : "No").append("\n");

            mensaje.append("\n------------------------\n");
        }

        JOptionPane.showMessageDialog(null, mensaje.toString());
    }

    private void abrirPanelBuscarMascota() {
        JTextField idMascotaField = new JTextField();

        JPanel panelBuscarMascota = new JPanel(new GridLayout(2, 1));
        panelBuscarMascota.add(new JLabel("Ingrese el ID de la mascota a buscar:"));
        panelBuscarMascota.add(idMascotaField);

        JButton confirmarButton = new JButton("Buscar");
        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idMascota = idMascotaField.getText();
                Mascota mascotaEncontrada = buscarMascotaPorID(idMascota);

                if (mascotaEncontrada != null) {
                    mostrarInformacionMascota(mascotaEncontrada);
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontró ninguna mascota con el ID: " + idMascota);
                }
            }
        });

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarPanelActual();
            }
        });

        panelBuscarMascota.add(confirmarButton);
        panelBuscarMascota.add(volverButton);

        actualizarPanel(panelBuscarMascota);
    }

    private Mascota buscarMascotaPorID(String idMascota) {
        for (Mascota mascota : listaMascotas) {
            if (mascota.getID().equals(idMascota)) {
                return mascota;
            }
        }
        return null;
    }

    private void mostrarInformacionMascota(Mascota mascota) {
        StringBuilder mensaje = new StringBuilder("Mascota encontrada:\n\n");
        mensaje.append("ID: ").append(mascota.getID()).append("\n");
        mensaje.append("Nombre: ").append(mascota.getNombre()).append("\n");
        mensaje.append("Tipo de Animal: ").append(mascota.getTipoAnimal()).append("\n");
        mensaje.append("Raza: ").append(mascota.getRaza()).append("\n");
        mensaje.append("Tamaño: ").append(mascota.getTamano()).append("\n");
        mensaje.append("Edad: ").append(mascota.getEdad()).append(" años\n");
        mensaje.append("Peso: ").append(mascota.getPeso()).append(" kg\n");
        mensaje.append("Fecha de Ingreso: ").append(mascota.getFechaIngreso()).append("\n");
        mensaje.append("Enfermedades: ").append(String.join(", ", mascota.getEnfermedades())).append("\n");
        mensaje.append("Esterilizado: ").append(mascota.isEsterilizado() ? "Sí" : "No").append("\n");
        mensaje.append("Adoptada: ").append(mascota.isAdoptada() ? "Sí" : "No").append("\n");

        JOptionPane.showMessageDialog(null, mensaje.toString());
    }

    private void cerrarPanelActual() {
        getContentPane().removeAll();
        revalidate();
        repaint();
        new Main2();  // Vuelve a crear la interfaz principal
    }

    private void actualizarPanel(JPanel nuevoPanel) {
        getContentPane().removeAll();
        getContentPane().add(nuevoPanel);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main2();
            }
        });
    }
}
