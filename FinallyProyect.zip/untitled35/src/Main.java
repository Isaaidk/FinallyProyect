import NovaVet.Donacion;
import NovaVet.Donante;
import NovaVet.Fecha;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main {

    private static ArrayList<Donante> donantesRegistrados = new ArrayList<>();
    private static JFrame frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        frame = new JFrame("Registro de Donantes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setSize(600, 400);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));

        JButton ingresarButton = new JButton("Ingresar Donante");
        JButton mostrarButton = new JButton("Mostrar Donantes");
        JButton salirButton = new JButton("Salir");

        ingresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelIngreso();
            }
        });

        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelLista();
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        mainPanel.add(ingresarButton);
        mainPanel.add(mostrarButton);
        mainPanel.add(salirButton);

        frame.add(mainPanel, BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static void mostrarPanelIngreso() {
        JPanel panelIngreso = new JPanel(new GridLayout(7, 2));
        JTextField ciField = new JTextField();
        JTextField nombreField = new JTextField();
        JTextField apellidoField = new JTextField();
        JTextField telefonoField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField montoField = new JTextField();

        panelIngreso.add(new JLabel("Cédula de Identidad (CI): "));
        panelIngreso.add(ciField);
        panelIngreso.add(new JLabel("Nombre: "));
        panelIngreso.add(nombreField);
        panelIngreso.add(new JLabel("Apellido: "));
        panelIngreso.add(apellidoField);
        panelIngreso.add(new JLabel("Teléfono: "));
        panelIngreso.add(telefonoField);
        panelIngreso.add(new JLabel("Correo Electrónico: "));
        panelIngreso.add(emailField);
        panelIngreso.add(new JLabel("Monto de la Donación: "));
        panelIngreso.add(montoField);

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                procesarIngresoDonante(ciField.getText(), nombreField.getText(), apellidoField.getText(),
                        telefonoField.getText(), emailField.getText(), montoField.getText());
            }
        });

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelInicio();
            }
        });

        panelIngreso.add(confirmarButton);
        panelIngreso.add(volverButton);

        actualizarPanel(panelIngreso);
    }

    private static void mostrarPanelLista() {
        StringBuilder listaDonantes = new StringBuilder("\nLista de donantes registrados:\n");
        for (Donante donante : donantesRegistrados) {
            listaDonantes.append("CI: ").append(donante.getCI()).append(", Nombre: ").append(donante.getNombre()).append(", Monto total donado: ").append(donante.getMonto()).append("\n");
        }

        JTextArea listaTextArea = new JTextArea(listaDonantes.toString());
        listaTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(listaTextArea);

        JButton volverButton = new JButton("Volver");
        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelInicio();
            }
        });

        JPanel panelLista = new JPanel(new BorderLayout());
        panelLista.add(scrollPane, BorderLayout.CENTER);
        panelLista.add(volverButton, BorderLayout.SOUTH);

        actualizarPanel(panelLista);
    }

    private static void mostrarPanelInicio() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));

        JButton ingresarButton = new JButton("Ingresar Donante");
        JButton mostrarButton = new JButton("Mostrar Donantes");
        JButton salirButton = new JButton("Salir");

        ingresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelIngreso();
            }
        });

        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelLista();
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        mainPanel.add(ingresarButton);
        mainPanel.add(mostrarButton);
        mainPanel.add(salirButton);

        actualizarPanel(mainPanel);
    }

    private static void actualizarPanel(JPanel nuevoPanel) {
        frame.getContentPane().removeAll();
        frame.repaint();

        frame.add(nuevoPanel, BorderLayout.CENTER);
        frame.revalidate();
    }

    private static void procesarIngresoDonante(String ci, String nombre, String apellido,
                                               String telefono, String email, String montoStr) {
        Donante donanteExistente = buscarDonanteByCI(ci);

        if (donanteExistente != null) {
            double montoDonacion = Double.parseDouble(montoStr);
            donanteExistente.setMonto(donanteExistente.getMonto() + montoDonacion);

            JOptionPane.showMessageDialog(frame, "Información actualizada del donante:\n" +
                    "Nombre: " + donanteExistente.getNombre() +
                    "\nMonto total donado: " + donanteExistente.getMonto());
            mostrarPanelInicio();
        } else {
            if (validarFormatoEmail(email)) {
                double monto = Double.parseDouble(montoStr);

                Donante nuevoDonante = new Donante(ci, nombre, apellido, telefono, email, monto);
                donantesRegistrados.add(nuevoDonante);

                double montoDonacion = Double.parseDouble(montoStr);
                Donacion nuevaDonacion = new Donacion(ci, nombre, apellido, telefono, email, new Fecha(), montoDonacion);
                nuevoDonante.registrarDonacion(nuevaDonacion);

                JOptionPane.showMessageDialog(frame, "Información del nuevo donante:\n" +
                        "Nombre: " + nuevoDonante.getNombre() +
                        "\nMonto total donado: " + nuevoDonante.getMonto());
                mostrarPanelInicio();
            } else {
                JOptionPane.showMessageDialog(frame, "Correo electrónico mal ingresado. Debe contener '@' y '.com'.");
            }
        }
    }

    private static Donante buscarDonanteByCI(String ci) {
        for (Donante donante : donantesRegistrados) {
            if (donante.getCI().equals(ci)) {
                return donante;
            }
        }
        return null;
    }

    private static boolean validarFormatoEmail(String email) {
        return email.contains("@") && email.contains(".com");
    }
}
