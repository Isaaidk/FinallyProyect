import NovaVet.Adoptante;
import NovaVet.Mascota;
import NovaVet.Solicitud;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Main3 {

    private List<Adoptante> adoptantes = new ArrayList<>();
    private List<Mascota> mascotasDisponibles = new ArrayList<>();

    private JTextField ciField;
    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField telefonoField;
    private JTextField emailField;
    private JTextField domicilioField;
    private JTextField edadField;
    private JTextField solicitudCiField;
    private JTextField solicitudDomicilioField;

    private JTextArea outputArea;

    public Main3() {
        // Crear la ventana principal
        JFrame frame = new JFrame("Sistema de Adopción");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Crear el panel principal
        JPanel mainPanel = new JPanel(new GridLayout(4, 1));
        frame.add(mainPanel);

        // Crear botones para las operaciones
        JButton nuevoAdoptanteBtn = new JButton("Ingresar Nuevo Adoptante");
        JButton mostrarAdoptantesBtn = new JButton("Mostrar Adoptantes");
        JButton hacerSolicitudBtn = new JButton("Hacer Solicitud");
        JButton mostrarSolicitudBtn = new JButton("Mostrar Solicitud por Adoptante");

        // Crear área de texto para mostrar información
        outputArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Agregar componentes al panel principal
        mainPanel.add(nuevoAdoptanteBtn);
        mainPanel.add(mostrarAdoptantesBtn);
        mainPanel.add(hacerSolicitudBtn);
        mainPanel.add(mostrarSolicitudBtn);
        mainPanel.add(scrollPane);

        // Agregar ActionListener a los botones
        nuevoAdoptanteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarVentanaNuevoAdoptante();
            }
        });

        mostrarAdoptantesBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarInformacionAdoptantes();
            }
        });

        hacerSolicitudBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarSolicitud();
                limpiarCampos();
            }
        });

        mostrarSolicitudBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarSolicitudesPorAdoptante();
            }
        });

        // Hacer visible la ventana
        frame.setVisible(true);
    }

    private void mostrarVentanaNuevoAdoptante() {
        // Crear la ventana para ingresar un nuevo adoptante
        JFrame nuevoAdoptanteFrame = new JFrame("Ingresar Nuevo Adoptante");
        nuevoAdoptanteFrame.setSize(400, 300);

        // Crear el panel para la ventana de nuevo adoptante
        JPanel nuevoAdoptantePanel = new JPanel(new GridLayout(8, 2));
        nuevoAdoptanteFrame.add(nuevoAdoptantePanel);

        // Crear campos de texto para la interfaz
        ciField = new JTextField();
        nombreField = new JTextField();
        apellidoField = new JTextField();
        telefonoField = new JTextField();
        emailField = new JTextField();
        domicilioField = new JTextField();
        edadField = new JTextField();

        // Crear etiquetas para los campos de texto
        JLabel ciLabel = new JLabel("CI del Adoptante:");
        JLabel nombreLabel = new JLabel("Nombre:");
        JLabel apellidoLabel = new JLabel("Apellido:");
        JLabel telefonoLabel = new JLabel("Teléfono:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel domicilioLabel = new JLabel("Domicilio:");
        JLabel edadLabel = new JLabel("Edad:");

        // Crear botón para confirmar ingreso de nuevo adoptante
        JButton confirmarBtn = new JButton("Confirmar");

        // Agregar componentes al panel de nuevo adoptante
        nuevoAdoptantePanel.add(ciLabel);
        nuevoAdoptantePanel.add(ciField);
        nuevoAdoptantePanel.add(nombreLabel);
        nuevoAdoptantePanel.add(nombreField);
        nuevoAdoptantePanel.add(apellidoLabel);
        nuevoAdoptantePanel.add(apellidoField);
        nuevoAdoptantePanel.add(telefonoLabel);
        nuevoAdoptantePanel.add(telefonoField);
        nuevoAdoptantePanel.add(emailLabel);
        nuevoAdoptantePanel.add(emailField);
        nuevoAdoptantePanel.add(domicilioLabel);
        nuevoAdoptantePanel.add(domicilioField);
        nuevoAdoptantePanel.add(edadLabel);
        nuevoAdoptantePanel.add(edadField);
        nuevoAdoptantePanel.add(confirmarBtn);

        // Agregar ActionListener al botón de confirmar
        confirmarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarNuevoAdoptante();
                limpiarCampos();
                nuevoAdoptanteFrame.dispose();
            }
        });

        // Hacer visible la ventana de nuevo adoptante
        nuevoAdoptanteFrame.setVisible(true);
    }

    private void limpiarCampos() {
        // Limpiar campos de texto
        ciField.setText("");
        nombreField.setText("");
        apellidoField.setText("");
        telefonoField.setText("");
        emailField.setText("");
        domicilioField.setText("");
        edadField.setText("");
        solicitudCiField.setText("");
        solicitudDomicilioField.setText("");
    }

    private void registrarNuevoAdoptante() {
        try {
            String ci = ciField.getText();
            String nombre = nombreField.getText();
            String apellido = apellidoField.getText();
            String telefono = telefonoField.getText();
            String email = emailField.getText();
            String domicilio = domicilioField.getText();
            int edad = Integer.parseInt(edadField.getText());

            Adoptante nuevoAdoptante = new Adoptante(ci, nombre, apellido, telefono, email, domicilio, edad);
            adoptantes.add(nuevoAdoptante);
            outputArea.append("Nuevo adoptante registrado con éxito.\n");
        } catch (NumberFormatException ex) {
            outputArea.append("Error al registrar nuevo adoptante. Asegúrate de ingresar datos válidos.\n");
        }
    }

    private void mostrarInformacionAdoptantes() {
        if (adoptantes.isEmpty()) {
            outputArea.append("No hay adoptantes registrados.\n");
        } else {
            outputArea.append("Lista de Adoptantes:\n");
            for (Adoptante adoptante : adoptantes) {
                outputArea.append("--------------------------------------------------\n");
                outputArea.append("CI: " + adoptante.getCI() + "\n");
                outputArea.append("Nombre: " + adoptante.getNombre() + "\n");
                outputArea.append("Apellido: " + adoptante.getApellido() + "\n");
                outputArea.append("Teléfono: " + adoptante.getTelefono() + "\n");
                outputArea.append("Email: " + adoptante.getEmail() + "\n");
                outputArea.append("Domicilio: " + adoptante.getDomicilio() + "\n");


                Mascota mascotaAdoptada = adoptante.getMascotaAdoptada();
                if (mascotaAdoptada != null) {
                    outputArea.append("Mascota Adoptada:\n");
                    outputArea.append("ID: " + mascotaAdoptada.getID() + "\n");
                    outputArea.append("Nombre: " + mascotaAdoptada.getNombre() + "\n");
                } else {
                    outputArea.append("No tiene mascota adoptada en este momento.\n");
                }

                ArrayList<Solicitud> solicitudes = adoptante.getSolicitudes();
                if (!solicitudes.isEmpty()) {
                    outputArea.append("Solicitudes Realizadas:\n");
                    for (Solicitud solicitud : solicitudes) {
                        outputArea.append("- Estado: " + (solicitud.isEstado() ? "Aprobada" : "Pendiente") + "\n");
                    }
                } else {
                    outputArea.append("No ha realizado solicitudes.\n");
                }
            }
        }
    }

    private void realizarSolicitud() {
        // Implementa la lógica para realizar una solicitud
        String ciAdoptante = solicitudCiField.getText();
        String domicilio = solicitudDomicilioField.getText();

        Mascota mascotaSeleccionada = seleccionarMascotaDisponible();

        if (mascotaSeleccionada == null) {
            outputArea.append("No hay mascotas disponibles para adoptar en este momento.\n");
            return;
        }

        Adoptante adoptante = obtenerAdoptantePorCI(ciAdoptante);

        if (adoptante != null) {
            Solicitud nuevaSolicitud = new Solicitud(adoptante, mascotaSeleccionada, false);
            nuevaSolicitud.setDomicilio(domicilio);
            adoptante.registrarSolicitud(nuevaSolicitud);

            outputArea.append("Solicitud realizada con éxito. Esperando aprobación.\n");
        } else {
            outputArea.append("No se encontró un adoptante con ese CI.\n");
        }
    }

    private void mostrarSolicitudesPorAdoptante() {
        // Implementa la lógica para mostrar las solicitudes por adoptante
        String ciAdoptante = solicitudCiField.getText();
        Adoptante adoptante = obtenerAdoptantePorCI(ciAdoptante);

        if (adoptante == null) {
            outputArea.append("No se encontró un adoptante con ese CI.\n");
            return;
        }

        ArrayList<Solicitud> solicitudes = adoptante.getSolicitudes();

        if (solicitudes.isEmpty()) {
            outputArea.append("El adoptante no tiene solicitudes registradas.\n");
        } else {
            outputArea.append("Solicitudes del Adoptante:\n");
            for (Solicitud solicitud : solicitudes) {
                outputArea.append("Fecha de Solicitud: " + solicitud.getFechaSolicitud() + "\n");
                outputArea.append("Mascota: " + solicitud.getMascota().getNombre() + "\n");
                outputArea.append("Estado: " + (solicitud.isEstado() ? "Aprobada" : "Pendiente") + "\n");
                outputArea.append("Domicilio: " + solicitud.getDomicilio() + "\n\n");
            }
        }
    }

    private Mascota seleccionarMascotaDisponible() {
        // Implementa la lógica para seleccionar una mascota disponible
        if (mascotasDisponibles.isEmpty()) {
            return null;
        } else {
            return mascotasDisponibles.get(0);
        }
    }

    private Adoptante obtenerAdoptantePorCI(String ciAdoptante) {
        // Implementa la lógica para obtener un adoptante por CI
        for (Adoptante adoptante : adoptantes) {
            if (adoptante.getCI().equals(ciAdoptante)) {
                return adoptante;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main3();
            }
        });
    }
}
