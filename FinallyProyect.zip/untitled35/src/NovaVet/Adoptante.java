package NovaVet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;


public class Adoptante {

    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    //Modela al adoptante
    private String CI;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private String domicilio;
    private double tamanoDom;
    private ArrayList<Solicitud> solicitudes;
    private Mascota mascotaAdoptada;//atravez de la solicitud
    private Fecha fechaNacimiento;

    //Constructor
    public Adoptante(String CI, String nombre, String apellido, String telefono, String email, String domicilio, double tamanoDom) {
        this.CI = CI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;

        this.domicilio = domicilio;
        this.tamanoDom = tamanoDom;
        this.fechaNacimiento = fechaNacimiento;  // Cambiando de edad a fecha de nacimiento


        this.solicitudes = new ArrayList<Solicitud>();
        //this.mascotaAdoptada = null; // Inicialmente, no tiene mascota asociada

    }
    public Fecha getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Fecha fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

   // Método para obtener la mascota adoptada

    public Mascota getMascotaAdoptada() {
      return mascotaAdoptada;
    }

    // Método para establecer la mascota adoptada
    public void setMascotaAdoptada(Mascota mascotaAdoptada) {
      this.mascotaAdoptada = mascotaAdoptada;
    }

    // Método para mostrar información del adoptante (modificado)
    public void mostrarInformacion() {
        System.out.println("Información del Adoptante:");
        System.out.println("CI: " + CI);
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Email: " + email);
        System.out.println("Domicilio: " + domicilio);
        System.out.println("Tamaño del Domicilio: " + tamanoDom);
        int edadActual = calcularEdadActual();
        System.out.println("Edad: " + edadActual);

        // Verificar si hay una mascota asociada
        if (mascotaAdoptada != null) {
            System.out.println("Mascota Adoptada:");
            System.out.println("ID: " + mascotaAdoptada.getID());
            System.out.println("Nombre de la Mascota: " + mascotaAdoptada.getNombre());
            // Agrega más detalles según sea necesario
        } else {
            System.out.println("No tiene mascota adoptada en este momento.");
        }

        // Resto del código...
    }




    //metodos
    public String getCI() {
        return CI;
    }
    public void setCI(String CI) {
        this.CI = CI;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getEmail() {
        return email;
    }

    public ArrayList<Solicitud> getSolicitudes() {
        return solicitudes;
    }
    public String getDomicilio() {
        return domicilio;
    }
    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }
    public double getTamanoDom() {
        return tamanoDom;
    }
    public void setTamanoDom(double tamanoDom) {
        this.tamanoDom = tamanoDom;
    }
    public void registrarSolicitud (Solicitud nuevasolicitud){solicitudes.add(nuevasolicitud);}

    public boolean tieneMascotasAdoptadas() {
        return false;
    }
    public void setEmail(String email) {
        if (validarFormatoEmail(email)) {
            this.email = email;
        } else {
            System.out.println("Correo electrónico mal ingresado. Debe contener '@' y '.com'.");
            solicitarNuevoEmail();
        }
    }

    private boolean validarFormatoEmail(String email) {
        return email != null && email.contains("@") && email.contains(".com");
    }

    private void solicitarNuevoEmail() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el correo electrónico nuevamente: ");
        String nuevoEmail = scanner.next();
        setEmail(nuevoEmail);
    }


    private int calcularEdadActual() {
        LocalDate fechaActual = LocalDate.now();
        int edadActual = fechaActual.getYear() - fechaNacimiento.getAnio();

        // Ajustamos la edad si aún no ha cumplido años en este año
        if (fechaActual.getMonthValue() < fechaNacimiento.getMes() ||
                (fechaActual.getMonthValue() == fechaNacimiento.getMes() &&
                        fechaActual.getDayOfMonth() < fechaNacimiento.getDia())) {
            edadActual--;
        }

        return edadActual;
    }


}
