package NovaVet;

import java.time.LocalDate;

public class HistoriaClinica {

    private LocalDate fecha;
    private String descripcion;

    public HistoriaClinica(LocalDate fecha, String descripcion) {
        this.fecha = fecha;
        this.descripcion = descripcion;
    }

    // Métodos getter y setter para fecha y descripción


    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    // Otros métodos si es necesario
}
