package NovaVet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Mascota {

    private String ID;
    private String nombre;
    private String tipoAnimal;
    private String raza;
    private String tamano;
    private int edad;
    private double peso;
    private ArrayList<String> enfermedades;
    private boolean esterilizado;
    private String descripcion;
    private LocalDate fechaIngreso;
    private boolean adoptada;

    private ArrayList<HistoriaClinica> historiaClinicas;
    private ArrayList<CitaMedica> citaMedicas;

    public Mascota(String ID, String nombre, String tipoAnimal, String raza, String tamano, int edad, double peso, ArrayList<String> enfermedades, boolean esterilizado, LocalDate fechaIngreso, ArrayList<HistoriaClinica> historiaClinicas, ArrayList<CitaMedica> citaMedicas) {
        this.ID = ID;
        this.nombre = nombre;
        this.tipoAnimal = tipoAnimal;
        this.raza = raza;
        this.tamano = tamano;
        this.edad = edad;
        this.peso = peso;
        this.enfermedades = new ArrayList<>();
        this.esterilizado = esterilizado;
        this.descripcion = descripcion;
        this.fechaIngreso = fechaIngreso;
        this.historiaClinicas = new ArrayList<>();
        this.citaMedicas = new ArrayList<>();
        this.adoptada = false; // Por defecto, la mascota no está adoptada al ser creada.

    }

    public void agregarEnfermedad(String enfermedad) {
        enfermedades.add(enfermedad);
    }
    public void modificarEnfermedades() {
        // Lógica para modificar enfermedades
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese nuevas enfermedades (separadas por coma): ");
        String nuevasEnfermedades = scanner.nextLine();

        // Limpiar la lista de enfermedades y agregar las nuevas
        enfermedades.clear();
        String[] nuevasEnfermedadesArray = nuevasEnfermedades.split(",");
        for (String enfermedad : nuevasEnfermedadesArray) {
            enfermedades.add(enfermedad.trim());
        }

        System.out.println("Enfermedades modificadas con éxito.");
    }
    public boolean isAdoptada() {
        return adoptada;
    }

    public void setAdoptada(boolean adoptada) {
        this.adoptada = adoptada;
    }
    // Métodos para agregar/modificar enfermedades
    public ArrayList<String> getEnfermedades() {
        return enfermedades;
    }

    public void setEnfermedades(ArrayList<String> enfermedades) {
        this.enfermedades = enfermedades;
    }

    // Método para modificar el estado de esterilización
    public boolean isEsterilizado() {
        return esterilizado;
    }

    public void setEsterilizado(boolean esterilizado) {
        this.esterilizado = esterilizado;
    }

    // Métodos para agregar/modificar descripción
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // Otros métodos existentes...

    // Resto de la clase...

    public String getID() {
        return ID;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipoAnimal() {
        return tipoAnimal;
    }

    public String getRaza() {
        return raza;
    }

    public String getTamano() {
        return tamano;
    }

    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public ArrayList<HistoriaClinica> getHistoriaClinicas() {
        return historiaClinicas;
    }

    public ArrayList<CitaMedica> getCitaMedicas() {
        return citaMedicas;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTipoAnimal(String tipoAnimal) {
        this.tipoAnimal = tipoAnimal;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public void setHistoriaClinicas(ArrayList<HistoriaClinica> historiaClinicas) {
        this.historiaClinicas = historiaClinicas;
    }

    public void setCitaMedicas(ArrayList<CitaMedica> citaMedicas) {
        this.citaMedicas = citaMedicas;
    }

    // Resto de la clase...



    // Métodos para gestionar citas médicas
    public void agregarCitaMedica(CitaMedica citaMedica) {
        if (citaMedicas == null) {
            citaMedicas = new ArrayList<>();
        }
        citaMedicas.add(citaMedica);
    }


    // Métodos para gestionar historias clínicas
    public void agregarHistoriaClinica(HistoriaClinica historiaClinica) {
        if (historiaClinicas == null) {
            historiaClinicas = new ArrayList<>();
        }
        historiaClinicas.add(historiaClinica);
    }







}
