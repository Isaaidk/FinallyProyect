package NovaVet;

public class Donacion {

    private String CI;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private double monto;
    private Fecha fechadonacion;
    private double montoDonacion;
    private int metodoPago;

    public Donacion(String CI, String nombre, String apellido, String telefono, String email, Fecha fecha, double montoDonacion) {
        this.CI = CI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
        this.fechadonacion = fechadonacion;
        this.montoDonacion = montoDonacion;
        this.fechadonacion = new Fecha();  // Crear un objeto Fecha con la fecha actual



    }
    public int getMetodoPago() {
        return metodoPago;
    }



    public Fecha getFechadonacion() {
        return fechadonacion;
    }

    public double getMontoDonacion() {
        return montoDonacion;
    }







    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }



    public void setFechadonacion(Fecha fechadonacion) {
        this.fechadonacion = fechadonacion;
    }

    public void setMontoDonacion(double montoDonacion) {
        this.montoDonacion = montoDonacion;
    }


}
