package NovaVet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Solicitud {

    private Adoptante adoptante;
    private Mascota mascota;
    private boolean estado;
   private String domicilio;//kitar domicilio a solicitud
    private Donante donante;
    private Donacion donacion;
    private LocalDate fechaSolicitud;
    //


    public Solicitud(Adoptante adoptante, Mascota mascota, boolean estado) {
        this.adoptante = adoptante;
        this.mascota = mascota;
        this.estado = estado;
        this.donante = null; // Inicialmente, no hay donante asociado a la solicitud.
        this.donacion = null;
        this.fechaSolicitud = LocalDate.now(); // Se establece la fecha de solicitud al momento de creación

    }
//
    public LocalDate getFechaSolicitud() {
        return fechaSolicitud;
    }

    public Donante getDonante() {
        return donante;
    }

    public Donacion getDonacion() {
        return donacion;
    }

    public Adoptante getAdoptante() {
        return adoptante;
    }

    public void setAdoptante(Adoptante adoptante) {
        this.adoptante = adoptante;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

   public String getDomicilio() {
    return domicilio;
    }

   public void setDomicilio(String domicilio) {
   this.domicilio = domicilio;
    }
    public boolean aceptacion() {
        return (adoptante.getTamanoDom() >= 100);
    }

    public void mostrarMascotasDisponibles() {
        if (estado && aceptacion()) {
            Mascota mascotaDisponible = datosMascota();
            if (mascotaDisponible != null) {
                System.out.println("Mascota Disponible:");
                System.out.println("Nombre: " + mascotaDisponible.getNombre());
                System.out.println("Tipo de Animal: " + mascotaDisponible.getTipoAnimal());
                System.out.println("Raza: " + mascotaDisponible.getRaza());
                // Agrega más detalles según sea necesario
            } else {
                System.out.println("No hay mascota asociada a esta solicitud.");
            }
        } else {
            System.out.println("La solicitud no está aceptada o no cumple con los requisitos.");
        }
    }

    public Mascota datosMascota() {
        if (estado) {
            return mascota;
        } else {
            return null;
        }
    }








    public void manejarSolicitud() {
        // Verificar si la solicitud está en un estado adecuado para continuar
        if (estado && aceptacion()) {
            // Mostrar mascotas disponibles
            mostrarMascotasDisponibles();

            // Preguntar al adoptante si desea hacer una donación
            Scanner scanner = new Scanner(System.in);
            System.out.print("¿Desea hacer una donación? (Sí/No): ");
            String respuesta = scanner.nextLine().toLowerCase();

            // Procesar la respuesta del adoptante
            if (respuesta.equals("si")) {
                // Crear una nueva donación
                Donacion nuevaDonacion = solicitarDonacion();

                // Asociar la donación a la solicitud
                asignarDonacion(nuevaDonacion);
            } else {
                System.out.println("Gracias por considerar la donación.");
            }
        } else {
            System.out.println("La solicitud no está aceptada o no cumple con los requisitos.");
        }
    }

    // Método para solicitar una donación al adoptante
    private Donacion solicitarDonacion() {
        Scanner scanner = new Scanner(System.in);

        // Solicitar información de la donación al adoptante
        System.out.println("Por favor, ingrese la información de la donación:");

        // Monto
        System.out.print("Monto de la donación: ");
        double montoDonacion = scanner.nextDouble();
        scanner.nextLine();  // Consumir el salto de línea

        // Otros detalles de la donación según sea necesario
        // Aquí puedes pedir más información como método de pago, detalles adicionales, etc.

        // Crear y devolver la nueva donación
        return new Donacion(
                adoptante.getCI(),
                adoptante.getNombre(),
                adoptante.getApellido(),
                adoptante.getTelefono(),
                adoptante.getEmail(),
                new Fecha(),  // Puedes ajustar cómo se establece la fecha según tus necesidades
                montoDonacion
        );
    }

    // Método para asignar una donación a la solicitud
    private void asignarDonacion(Donacion nuevaDonacion) {
        donante = new Donante(adoptante.getCI(), adoptante.getNombre(), adoptante.getApellido(),
                adoptante.getTelefono(), adoptante.getEmail(), nuevaDonacion.getMonto());

        donacion = nuevaDonacion;
        donante.registrarDonacion(nuevaDonacion);
        adoptante.registrarSolicitud(this);
    }



    public void aprobarSolicitud(ArrayList<Mascota> listaMascotasDisponibles) {
        if (estado && aceptacion()) {
            mostrarMascotasDisponibles(listaMascotasDisponibles);
            Scanner scanner = new Scanner(System.in);
            System.out.print("Ingrese el ID de la mascota que desea adoptar: ");
            String idMascota = scanner.nextLine();

            Mascota mascotaSeleccionada = buscarMascotaPorID(idMascota, listaMascotasDisponibles);

            if (mascotaSeleccionada != null && !mascotaSeleccionada.isAdoptada()) {
                // Marcar la mascota como adoptada
                mascotaSeleccionada.setAdoptada(true);

                // Asociar la mascota al adoptante
                setMascota(mascotaSeleccionada);

                // Marcar la solicitud como aprobada
                setEstado(true);

                System.out.println("¡Adopción exitosa! " + getDonante() + " adoptó a " + mascotaSeleccionada.getNombre());
            } else {
                System.out.println("La mascota no está disponible para adopción o ya fue adoptada.");
            }
        } else {
            System.out.println("La solicitud no está aceptada o no cumple con los requisitos.");
        }
    }

    // Método para buscar una mascota por su ID
    private Mascota buscarMascotaPorID(String idMascota, ArrayList<Mascota> listaMascotas) {
        for (Mascota mascota : listaMascotas) {
            if (mascota.getID().equals(idMascota)) {
                return mascota;
            }
        }
        return null;
    }

    // Método para mostrar las mascotas disponibles
    private void mostrarMascotasDisponibles(ArrayList<Mascota> listaMascotas) {
        System.out.println("Mascotas Disponibles:");
        for (Mascota mascota : listaMascotas) {
            if (!mascota.isAdoptada()) {
                System.out.println("ID: " + mascota.getID() + ", Nombre: " + mascota.getNombre());
            }
        }
    }



}
