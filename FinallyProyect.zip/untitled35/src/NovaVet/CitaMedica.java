package NovaVet;

import java.time.LocalDate;

public class CitaMedica {

    private LocalDate fecha;
    private String motivo;
    private String resultado;

    public CitaMedica(LocalDate fecha, String motivo, String resultado) {
        this.fecha = fecha;
        this.motivo = motivo;
        this.resultado = resultado;
    }

    // Métodos getter y setter para fecha, motivo y resultado


    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getMotivo() {
        return motivo;
    }

    public String getResultado() {
        return resultado;
    }

    // Otros métodos si es necesario
}
